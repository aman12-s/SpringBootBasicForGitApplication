package com.gl.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBasicForGitApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBasicForGitApplication.class, args);
	}

}
